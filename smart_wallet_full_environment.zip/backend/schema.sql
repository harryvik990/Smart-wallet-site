CREATE TABLE transactions (
  id SERIAL PRIMARY KEY,
  hash TEXT,
  amount TEXT,
  sender TEXT,
  receiver TEXT,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
