import React from 'react';

function App() {
  return (
    <div className="bp4-dark">
      <h1>Smart Wallet UI Template</h1>
    </div>
  );
}

export default App;
